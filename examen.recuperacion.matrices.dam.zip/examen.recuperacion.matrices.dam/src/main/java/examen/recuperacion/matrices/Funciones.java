package examen.recuperacion.matrices;

import java.util.Random;
/**
 * Proyecto en el cual intetno imprimir una matriz float.
 * @author Daniel Cesar Vargas Holguin
 *
 */
public class Funciones {
	/**
	 * Funcion que se encarga de generar dentro de la matriz float un numero aleatorio entre 0,1
	 * @param nFilas de la matriz
	 * @param nColumnas de la matriz
	 */
	public static void generaMatrizFloat (byte nFilas, byte nColumnas) {
		
		Random r = new Random();
		
		float[][]matriz=new float[nFilas][nColumnas];
		for(byte i=0;i<matriz.length;i++){
            for(byte j=0;j<matriz[i].length;j++){
                matriz[i][j]=(byte)r.nextInt(0,2);
            }
        }
	}
	/**
	 * Esta funcion tiene que recibir una matriz de float con todas las posiciones rellenas entre 0 y 1
	 * @param matriz es una matriz de float
	 * @return devuelve el numero de filas contando en esa filas la suma de sus valores de todas sus columnas 2 o mas
	 */
	public static byte sumatoriaMasDeDos (float[][] matriz) {
		
		for (byte i = 0; i < matriz.length; i++) {
			matriz[i][0] = 2+matriz[0].length;
		}
		return (byte) matriz.length;
	}
	/**
	 * imprime una matriz
	 * @param matriz se refiere una mtriz float
	 * @return concatenado el contenido de la matriz de cada hueco.
	 */
	public static String imprimeMatriz(float[][] matriz) {
		String ret = "";
		for (byte i = 0; i < matriz.length; i++) {
			for (byte j = 0; j < matriz[0].length; j++) {
				ret += matriz[i][j];
				ret += "\t";
			}
			ret += "\n";
		}
		
		return ret;
	}
}
