package examen.recuperacion.matrices;

import java.util.Scanner;
/**
 *  Clase main donde se realizará el examen de recuperacion de matrices.
 *  Trata de imprimir una matriz de tipo float.
 * @author Daniel Cesar Vargas Holguin
 *
 */
public class Principal {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		byte nFilas = 0;
		byte nColumnas = 0;
		byte nMatrices=0;
		do {
			System.out.println("Dime cuantas filas quiere que tenga tu matriz");
			nFilas = Byte.parseByte(sc.nextLine());
			System.out.println("Dime cuantas columnas quiere que tenga tu matriz");
			nColumnas = Byte.parseByte(sc.nextLine());
			
		} while (nFilas < 5 || nColumnas < 5 || nFilas > 10 || nColumnas > 10);
		
		System.out.println("Dime cuantas matrices quieres");
		nMatrices=Byte.parseByte(sc.nextLine());
		
		float matriz[][] = new float[nFilas][nColumnas]; 
		Funciones.generaMatrizFloat(nFilas, nColumnas);
		Funciones.sumatoriaMasDeDos(matriz);
		System.out.println(Funciones.imprimeMatriz(matriz));
	}

}
