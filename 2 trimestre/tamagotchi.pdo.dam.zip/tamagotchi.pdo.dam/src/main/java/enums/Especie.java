package enums;

public enum Especie {
	PERRO,
	DRAGON,
	GATO,
	POLLITO
}
