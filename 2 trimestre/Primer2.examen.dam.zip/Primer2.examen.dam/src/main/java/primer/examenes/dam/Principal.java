package primer.examenes.dam;

import java.util.Scanner;

public class Principal {
	/**
	 * Este proyecto Vamos a conmemorar la festividad mayor del pueblo de
	 * “Villacateto del Secaero” con la siguientes funciones.
	 * 
	 * @param args se usa.
	 */
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		byte tam = -1;

		// Ejercicio 9
		for (byte i = 0; i < args.length; i++) {
			if (args[i].equals("-tam")) {
				tam = Byte.parseByte(args[i + 1]);
			}
		}

		if (tam == -1) {
			// Ejercicio 4
			System.out.println("Dime un tamaño para la matriz (12-16)");
			tam = Byte.parseByte(sc.nextLine());
		}

		// System.out.println("Dime un tamaño para la matriz");
		// byte tamaño = Byte.parseByte(sc.nextLine());

		char[][] escena = Funciones.creaMatrizEspacios(tam);

		if (escena != null) {
			Funciones.ponerNubes(escena);
			Funciones.insertarFraseEufrasio(escena);
			Funciones.generarEscena(escena);
			System.out.println(Funciones.imprimeMatriz(escena));
		} else {
			System.out.println("Vuelve intentarlo");
		}
	}

}
