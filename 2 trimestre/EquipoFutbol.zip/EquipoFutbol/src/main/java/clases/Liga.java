package clases;

import java.util.ArrayList;

public class Liga extends Presupuesto{
	
	private byte minimoEquiposParticipantes;
	private byte maximoEquiposParticipantes;
	private ArrayList<Equipo>equipos;
	private ArrayList<Partido>partidos;
	
	public Liga(String nombre, float presupuesto, byte minimoEquiposParticipantes, byte maximoEquiposParticipantes,
			ArrayList<Equipo> equipos, ArrayList<Partido> partidos) {
		super(nombre, presupuesto);
		this.minimoEquiposParticipantes = minimoEquiposParticipantes;
		this.maximoEquiposParticipantes = maximoEquiposParticipantes;
		this.equipos = equipos;
		this.partidos = partidos;
	}

	public byte getMinimoEquiposParticipantes() {
		return minimoEquiposParticipantes;
	}

	public void setMinimoEquiposParticipantes(byte minimoEquiposParticipantes) {
		this.minimoEquiposParticipantes = minimoEquiposParticipantes;
	}

	public byte getMaximoEquiposParticipantes() {
		return maximoEquiposParticipantes;
	}

	public void setMaximoEquiposParticipantes(byte maximoEquiposParticipantes) {
		this.maximoEquiposParticipantes = maximoEquiposParticipantes;
	}

	public ArrayList<Equipo> getEquipos() {
		return equipos;
	}

	public void setEquipos(ArrayList<Equipo> equipos) {
		this.equipos = equipos;
	}

	public ArrayList<Partido> getPartidos() {
		return partidos;
	}

	public void setPartidos(ArrayList<Partido> partidos) {
		this.partidos = partidos;
	}

	public String toString() {
		
		return super.toString()+"\n\n"+partidos;
	}
	
	
}
