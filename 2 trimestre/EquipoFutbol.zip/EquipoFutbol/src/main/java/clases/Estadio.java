package clases;

public class Estadio extends CosaConNombre {
	
	private String direccionCompleta;
	private String ciudad;
	private int capacidad;
	
	public Estadio(String nombre, String direccionCompleta, String ciudad, int capacidad) {
		super(nombre);
		this.direccionCompleta = direccionCompleta;
		this.ciudad = ciudad;
		this.capacidad = capacidad;
	}

	public String getDireccionCompleta() {
		return direccionCompleta;
	}

	public void setDireccionCompleta(String direccionCompleta) {
		this.direccionCompleta = direccionCompleta;
	}

	public String getCiudad() {
		return ciudad;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	public int getCapacidad() {
		return capacidad;
	}

	public void setCapacidad(int capacidad) {
		this.capacidad = capacidad;
	}

	
	
	
	
}
