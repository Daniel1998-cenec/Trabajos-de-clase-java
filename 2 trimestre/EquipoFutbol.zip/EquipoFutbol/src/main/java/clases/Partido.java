package clases;

import java.time.LocalTime;

public class Partido {
	
	private byte golesLocal;
	private byte golesVisitante;
	private LocalTime diaYHora;
	private Equipo equipoLocal;
	private Equipo equipoVisitante;
	
	public Partido(byte golesLocal, byte golesVisitante, Equipo equipoLocal, Equipo equipoVisitante) {
		super();
		this.golesLocal = golesLocal;
		this.golesVisitante = golesVisitante;
		this.diaYHora = LocalTime.now();
		this.equipoLocal = equipoLocal;
		this.equipoVisitante = equipoVisitante;
	}

	public byte getGolesLocal() {
		return golesLocal;
	}

	public void setGolesLocal(byte golesLocal) {
		this.golesLocal = golesLocal;
	}

	public byte getGolesVisitante() {
		return golesVisitante;
	}

	public void setGolesVisitante(byte golesVisitante) {
		this.golesVisitante = golesVisitante;
	}

	public LocalTime getDiaYHora() {
		return diaYHora;
	}

	public void setDiaYHora(LocalTime diaYHora) {
		this.diaYHora = diaYHora;
	}

	public Equipo getEquipoLocal() {
		return equipoLocal;
	}

	public void setEquipoLocal(Equipo equipoLocal) {
		this.equipoLocal = equipoLocal;
	}

	public Equipo getEquipoVisitante() {
		return equipoVisitante;
	}

	public void setEquipoVisitante(Equipo equipoVisitante) {
		this.equipoVisitante = equipoVisitante;
	}

	
	public String toString() {
		
		return diaYHora+" "+ equipoLocal.getEstadio().getNombre() +"("+ equipoLocal.getEstadio().getCiudad() +")\n"+
				equipoLocal +" "+ golesLocal + "\n" +equipoVisitante+" "+ golesVisitante;
	}
	
	

}
