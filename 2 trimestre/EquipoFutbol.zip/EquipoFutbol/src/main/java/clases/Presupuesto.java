package clases;

abstract class Presupuesto extends CosaConNombre{
	
	private float presupuesto;

	public Presupuesto(String nombre, float presupuesto) {
		super(nombre);
		this.presupuesto = presupuesto;
	}

	public float getPresupuesto() {
		return presupuesto;
	}

	public void setPresupuesto(float presupuesto) {
		this.presupuesto = presupuesto;
	}

	
	
	
	


}
