package clases;

public class Equipo extends Presupuesto {
	
	private Estadio estadio;

	public Equipo(String nombre, float presupuesto, Estadio estadio) {
		super(nombre, presupuesto);
		this.estadio = estadio;
	}

	public Estadio getEstadio() {
		return estadio;
	}

	public void setEstadio(Estadio estadio) {
		this.estadio = estadio;
	}

	
	
	
	
	

}
