package equipo.de.futbol.dam;

import java.util.ArrayList;
import java.util.Scanner;

import clases.Equipo;
import clases.Estadio;
import clases.Liga;
import clases.Partido;

public class Principal {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		Estadio barcelona=new Estadio("Spotify Camp Nou", "C. d'Arístides Maillol, 12", "Barcelona", 99354);
		Estadio madrid=new Estadio("Estadio Santiago Bernabéu", "Av. de Concha Espina, 1", "Madrid", 81044);
		
		ArrayList<Equipo>equipos=new ArrayList<Equipo>();
		Equipo fcBarcelona=new Equipo("FCBarcelona", 50.2f, barcelona);
		Equipo fcMadrid=new Equipo("Real Madrid C.F.", 60.5f, madrid);
		equipos.add(fcBarcelona);
		equipos.add(fcMadrid);
		
		ArrayList<Partido>partidos=new ArrayList<Partido>();
		Partido partido1=new Partido((byte)2,(byte)5, fcMadrid, fcBarcelona);
		Partido partido2=new Partido((byte)5, (byte)0, fcBarcelona, fcMadrid);
		partidos.add(partido1);
		partidos.add(partido2);
		
		Liga ligaEspañola=new Liga("Liga BBVA", 200.5f, (byte)2, (byte)5, equipos, partidos);
		
		System.out.println(ligaEspañola);
	}

}
