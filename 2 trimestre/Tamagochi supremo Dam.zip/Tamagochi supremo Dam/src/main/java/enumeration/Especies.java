package enumeration;

public enum Especies {

	PERRO,
	GATO,
	DRAGÓN,
	POLLITO
	
}
