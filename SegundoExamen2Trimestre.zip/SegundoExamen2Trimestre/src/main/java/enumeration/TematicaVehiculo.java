package enumeration;

public enum TematicaVehiculo {

	COCHE_BOMBEROS,
	AMBULANCIA,
	COCHE_BATMAN,
	COHETE,
	TRONCOMOVIL
}
