package main;

import java.util.ArrayList;
import java.util.Scanner;

import clases.Caballo;
import clases.Comida;
import clases.Feria;
import clases.Noria;
import clases.PuestoComida;
import clases.TioVivo;
import clases.Vehiculo;
import enumeration.TematicaVehiculo;

public class Principal {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		//Comida
		Comida perritoCaliente=new Comida("Perrito Caliente", 2.5f);
		Comida pizza=new Comida("Pizza",5.5f);
		
		Caballo caballo1=new Caballo((byte)1);
		Caballo caballo2=new Caballo((byte)2);
		Caballo caballo3=new Caballo((byte)2);
		Caballo caballo4=new Caballo((byte)1);
		Caballo caballo5=new Caballo((byte)1);
		Caballo caballo6=new Caballo((byte)2);
		Caballo caballo7=new Caballo((byte)1);
		Caballo caballo8=new Caballo((byte)1);
		Caballo caballo9=new Caballo((byte)2);
		Caballo caballo10=new Caballo((byte)2);
		
		Vehiculo vehiculo1=new Vehiculo((byte)2, false, TematicaVehiculo.AMBULANCIA);
		Vehiculo vehiculo2=new Vehiculo((byte)2, true, TematicaVehiculo.COCHE_BATMAN);
		Vehiculo vehiculo3=new Vehiculo((byte)3, true, TematicaVehiculo.COCHE_BOMBEROS);
		Vehiculo vehiculo4=new Vehiculo((byte)4, false, TematicaVehiculo.COHETE);
		Vehiculo vehiculo5=new Vehiculo((byte)2, true, TematicaVehiculo.TRONCOMOVIL);
		Vehiculo vehiculo6=new Vehiculo((byte)3, false, TematicaVehiculo.TRONCOMOVIL);
		Vehiculo vehiculo7=new Vehiculo((byte)4, true, TematicaVehiculo.COHETE);
		Vehiculo vehiculo8=new Vehiculo((byte)2, true, TematicaVehiculo.COCHE_BATMAN);
		Vehiculo vehiculo9=new Vehiculo((byte)2, false, TematicaVehiculo.AMBULANCIA);
		Vehiculo vehiculo10=new Vehiculo((byte)3, true, TematicaVehiculo.COCHE_BOMBEROS);
		
		ArrayList<Caballo> caballos = new ArrayList<Caballo>();
		caballos.add(caballo1);
		caballos.add(caballo2);
		caballos.add(caballo3);
		caballos.add(caballo4);
		caballos.add(caballo5);
		
		ArrayList<Caballo> caballosPro = new ArrayList<Caballo>();
		caballos.add(caballo6);
		caballos.add(caballo7);
		caballos.add(caballo8);
		caballos.add(caballo9);
		caballos.add(caballo10);
		
		ArrayList<Vehiculo> vehiculos = new ArrayList<Vehiculo>();
		vehiculos.add(vehiculo1);
		vehiculos.add(vehiculo2);
		vehiculos.add(vehiculo3);
		vehiculos.add(vehiculo4);
		vehiculos.add(vehiculo5);
		
		ArrayList<Vehiculo> vehiculosPro = new ArrayList<Vehiculo>();
		vehiculos.add(vehiculo6);
		vehiculos.add(vehiculo7);
		vehiculos.add(vehiculo8);
		vehiculos.add(vehiculo9);
		vehiculos.add(vehiculo10);
		
		ArrayList<PuestoComida> puestoDeComidas = new ArrayList<PuestoComida>();
		
		PuestoComida pepito=new PuestoComida("Pepito", pizza);
		puestoDeComidas.add(pepito);
		PuestoComida laCatedral=new PuestoComida("Pepito", perritoCaliente);
		puestoDeComidas.add(laCatedral);
		
		ArrayList<TioVivo>tioVivos=new ArrayList<TioVivo>();
		
		TioVivo correCamino=new TioVivo("correCamino", 2.5f, caballos, vehiculos);
		TioVivo badBunny=new TioVivo("badBunny", 3.5f, caballosPro, vehiculosPro);
		
		ArrayList<Noria>norias=new ArrayList<Noria>();
		
		Noria conejoMalo= new Noria("conejoMalo", 4.5f,(short) 250,(byte) 20,(byte) 2);
		Noria conejobueno= new Noria("conejobueno", 4.5f,(short) 500,(byte) 50,(byte) 4);
		
		Feria nuevaFeria=new Feria(puestoDeComidas, norias, tioVivos);
		
		System.out.println(nuevaFeria);
	}

}
