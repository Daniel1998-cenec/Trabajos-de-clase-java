package clases;

abstract class Ficha extends CosaConNombre {
	
	private float precioFicha;

	public Ficha(String nombre, float precioFicha) {
		super(nombre);
		this.precioFicha = precioFicha;
	}

	public float getPrecioFicha() {
		return precioFicha;
	}

	public void setPrecioFicha(float precioFicha) {
		this.precioFicha = precioFicha;
	}

	public String toString() {
		return super.toString()+"\n\tPrecioFicha: " + precioFicha;
	}
	
	

}
