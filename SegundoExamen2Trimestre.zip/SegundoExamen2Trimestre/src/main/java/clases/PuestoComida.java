package clases;

public class PuestoComida extends CosaConNombre {
	
	private boolean puedeVenderAlcohol;
	private Comida comidasEnVenta;
	
	public PuestoComida(String nombre, Comida comidasEnVenta) {
		super(nombre);
		this.puedeVenderAlcohol = true;
		this.comidasEnVenta = comidasEnVenta;
	}

	public boolean getPuedeVenderAlcohol() {
		return puedeVenderAlcohol;
	}

	public void setPuedeVenderAlcohol(boolean puedeVenderAlcohol) {
		this.puedeVenderAlcohol = puedeVenderAlcohol;
	}

	public Comida getComidasEnVenta() {
		return comidasEnVenta;
	}

	public void setComidasEnVenta(Comida comidasEnVenta) {
		this.comidasEnVenta = comidasEnVenta;
	}

	public String toString() {
		return super.toString()+"\n\tVentaDeAlcohol: " + puedeVenderAlcohol + "\n\tComidasEnVenta=" + comidasEnVenta;
	}
	
	

}
