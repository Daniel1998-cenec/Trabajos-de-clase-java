package clases;

public class MayorDeEdad {
	
	private byte edadMinima;
	private byte numeroPlazas;
	
	public MayorDeEdad( byte numeroPlazas) {
		super();
		this.edadMinima = 7;
		this.numeroPlazas = numeroPlazas;
	}

	public byte getEdadMinima() {
		return edadMinima;
	}

	public void setEdadMinima(byte edadMinima) {
		this.edadMinima = edadMinima;
	}

	public byte getNumeroPlazas() {
		return numeroPlazas;
	}

	public void setNumeroPlazas(byte numeroPlazas) {
		this.numeroPlazas = numeroPlazas;
	}

	
	public String toString() {
		return "\n\tEdadMinima: " + edadMinima + "\n\tNumeroPlazas: " + numeroPlazas;
	}
	
	

}
