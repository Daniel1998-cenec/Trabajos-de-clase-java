package clases;

import java.util.ArrayList;

public class TioVivo extends Ficha {
	
	private ArrayList<Caballo>caballos;
	private ArrayList<Vehiculo>vehiculos;
	
	public TioVivo(String nombre, float precioFicha, ArrayList<Caballo> caballos, ArrayList<Vehiculo> vehiculos) {
		super(nombre, precioFicha);
		this.caballos = caballos;
		this.vehiculos = vehiculos;
	}

	public ArrayList<Caballo> getCaballos() {
		return caballos;
	}

	public void setCaballos(ArrayList<Caballo> caballos) {
		this.caballos = caballos;
	}

	public ArrayList<Vehiculo> getVehiculos() {
		return vehiculos;
	}

	public void setVehiculos(ArrayList<Vehiculo> vehiculos) {
		this.vehiculos = vehiculos;
	}

	
	public String toString() {
		return super.toString()+"\n\tCaballo: " + caballos + "\n\tVehiculo:" + vehiculos;
	}
	
	
	
	

}
