package clases;

import java.util.ArrayList;

public class Feria {

	private ArrayList<PuestoComida> puestoComida;
	private ArrayList<Noria>noria;
	private ArrayList<TioVivo>tioVivo;
	
	public Feria(ArrayList<PuestoComida> puestoComida, ArrayList<Noria> noria, ArrayList<TioVivo> tioVivo) {
		super();
		this.puestoComida = puestoComida;
		this.noria = noria;
		this.tioVivo = tioVivo;
	}

	public ArrayList<PuestoComida> getPuestoComida() {
		return puestoComida;
	}

	public void setPuestoComida(ArrayList<PuestoComida> puestoComida) {
		this.puestoComida = puestoComida;
	}

	public ArrayList<Noria> getNoria() {
		return noria;
	}

	public void setNoria(ArrayList<Noria> noria) {
		this.noria = noria;
	}

	public ArrayList<TioVivo> getTioVivo() {
		return tioVivo;
	}

	public void setTioVivo(ArrayList<TioVivo> tioVivo) {
		this.tioVivo = tioVivo;
	}

	
	public String toString() {
		return "\n\tPuestoComida: " + puestoComida + "\n\tNoria: " + noria + "\n\tTioVivo=" + tioVivo;
	}
	
	
}
