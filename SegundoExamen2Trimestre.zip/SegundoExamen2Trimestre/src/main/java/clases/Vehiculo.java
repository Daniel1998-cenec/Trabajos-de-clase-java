package clases;

import enumeration.TematicaVehiculo;

public class Vehiculo extends Caballo {

	private boolean tieneBocinas;
	private TematicaVehiculo tipoDeVehiculo;
	
	public Vehiculo(byte numeroPlazas, boolean tieneBocinas, TematicaVehiculo tipoDeVehiculo) {
		super(numeroPlazas);
		this.tieneBocinas = tieneBocinas;
		this.tipoDeVehiculo = tipoDeVehiculo;
	}

	public boolean isTieneBocinas() {
		return tieneBocinas;
	}

	public void setTieneBocinas(boolean tieneBocinas) {
		this.tieneBocinas = tieneBocinas;
	}

	public TematicaVehiculo getTipoDeVehiculo() {
		return tipoDeVehiculo;
	}

	public void setTipoDeVehiculo(TematicaVehiculo tipoDeVehiculo) {
		this.tipoDeVehiculo = tipoDeVehiculo;
	}

	
	public String toString() {
		return super.toString()+"\n\tTieneBocinas: " + tieneBocinas + "\n\tTipoDeVehiculo: " + tipoDeVehiculo;
	}
	
	
}
