package clases;

public class Caballo extends MayorDeEdad {

	public Caballo( byte numeroPlazas) {
		super( numeroPlazas);
	}

	
}
