package clases;

public class Noria extends Ficha {
	
	private short alturaMetros;
	private byte numeroCabinas;
	private byte asientosPorCabina;
	
	public Noria(String nombre, float precioFicha, short alturaMetros, byte numeroCabinas, byte asientosPorCabina) {
		super(nombre, precioFicha);
		this.alturaMetros = alturaMetros;
		this.numeroCabinas = numeroCabinas;
		this.asientosPorCabina = asientosPorCabina;
	}

	public short getAlturaMetros() {
		return alturaMetros;
	}

	public void setAlturaMetros(short alturaMetros) {
		this.alturaMetros = alturaMetros;
	}

	public byte getNumeroCabinas() {
		return numeroCabinas;
	}

	public void setNumeroCabinas(byte numeroCabinas) {
		this.numeroCabinas = numeroCabinas;
	}

	public byte getAsientosPorCabina() {
		return asientosPorCabina;
	}

	public void setAsientosPorCabina(byte asientosPorCabina) {
		this.asientosPorCabina = asientosPorCabina;
	}

	
	public String toString() {
		return super.toString()+"\n\tAlturaMetros: " + alturaMetros + "\n\tNumeroCabinas: " + numeroCabinas + "\n\tAsientosPorCabina: "
				+ asientosPorCabina;
	}
	
	

}
